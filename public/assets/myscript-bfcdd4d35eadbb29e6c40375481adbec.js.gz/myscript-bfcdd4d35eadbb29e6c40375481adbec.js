$(document).ready(function() {
  $('.gallery').lightGallery({
       thumbnail:true,
    animateThumb: false,
    showThumbByDefault: false
}); 
    
    
});
